#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include "matrix.h"
using namespace std;

//! Tests operation of vector/matrix classes

int main()
{
	Matrix G(5,3);
	Vec a(3), b(3);
	int i, j;
	for (i=0; i<3; i++) {
		a[i] = i+1;
		b[i] = i-1;
	}
	printf("vector a =\n");
	a.print();
	cout << a << endl;
	printf("vector b =\n");
	b.print();
	Vec c = a+b; //vec::add(a,b);
	printf("vector a + b =\n");
	c.print();
	c = a; // copy vector to c
	a[0] = 4;
	printf("element by element sqrt:\n");
	c.apply(sqrt).print();

	printf("a dot b = %g\n",Vec::dot(a,b));
	
	for (j=0; j<G.cols(); j++) {
		for (i=0; i<G.rows(); i++) G[i][j] = (i+1)*10 + (j+1);
	}
	printf("matrix G =\n");
	G.print();
	Vec d = G*b; // Matrix::mul(G,b);
	printf("G*b = \n");
	cout << d << endl;
	printf("matrix %d x %d\n",G.rows(),G.cols());
	Vec e(5);
	for (i=0; i<5; i++) e[i]=i-2;
	printf("vector e = \n");
	cout << e << endl;
	Vec f = e*G; //Matrix::mul(e,G);
	printf("e*G =\n");
	cout << f << endl;
	return EXIT_SUCCESS;
}